#include "BatchNorm.h"
#include "common.h"
#include <vector>
BatchNorm::BatchNorm(cudnnHandle_t cudnnHandle, cudnnTensorDescriptor_t outDesc, cudnnBatchNormMode_t bnMode, int bitchSize): cudnnHandle_(cudnnHandle), bnMode_(bnMode), bitchSize_(bitchSize), inData_(nullptr){
	outDesc_ = outDesc;
	cudnnDataType_t dt;
	int n, c, h, w, ns, cs, hs, ws;
	cudnnGetTensor4dDescriptor(outDesc_, &dt, &n, &c, &h, &w, &ns, &cs, &hs, &ws);
	outSize_ = n * c * h * w;
	outC_ = c;
	checkCUDNN(cudnnCreateTensorDescriptor(&gradDesc_));
	checkCUDNN(cudnnCreateTensorDescriptor(&bnScaleBiasDesc_));
	checkCUDNN(cudnnSetTensor4dDescriptor(gradDesc_, CUDNN_TENSOR_NCHW, CUDNN_DATA_HALF, n, c, h, w));
	checkCUDNN(cudnnDeriveBNTensorDescriptor(bnScaleBiasDesc_, outDesc_, bnMode_));
	checkCUDA(cudaMalloc(&outData_, outSize_*sizeof(__half)));
	checkCUDA(cudaMemset(outData_, 0, outSize_*sizeof(__half)));
	const auto bnSizeBytes = outC_ * sizeof(float);
	checkCUDA(cudaMalloc(&bnScale_, bnSizeBytes));
	checkCUDA(cudaMalloc(&bnBias_, bnSizeBytes));
	checkCUDA(cudaMalloc(&gradBnScale_, bnSizeBytes));
	checkCUDA(cudaMalloc(&gradBnBias_, bnSizeBytes));
	checkCUDA(cudaMalloc(&bnRunningMean_, bnSizeBytes));
	checkCUDA(cudaMalloc(&bnRunningVar_, bnSizeBytes));
	checkCUDA(cudaMalloc(&bnSavedMean_, bnSizeBytes));
	checkCUDA(cudaMalloc(&bnSavedInvVariance_, bnSizeBytes));
	const std::vector<float> bnScaleInit(outC_, 1.0f);
	checkCUDA(cudaMemcpy(bnScale_, bnScaleInit.data(), bnSizeBytes, cudaMemcpyHostToDevice));
	checkCUDA(cudaMemset(bnBias_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(gradBnScale_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(gradBnBias_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(bnRunningMean_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(bnRunningVar_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(bnSavedMean_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(bnSavedInvVariance_, 0, bnSizeBytes));
	checkCUDA(cudaMalloc(&m_bnScale_, bnSizeBytes));
	checkCUDA(cudaMalloc(&v_bnScale_, bnSizeBytes));
	checkCUDA(cudaMalloc(&m_bnBias_, bnSizeBytes));
	checkCUDA(cudaMalloc(&v_bnBias_, bnSizeBytes));
	checkCUDA(cudaMemset(m_bnScale_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(v_bnScale_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(m_bnBias_, 0, bnSizeBytes));
	checkCUDA(cudaMemset(v_bnBias_, 0, bnSizeBytes));
}
BatchNorm::~BatchNorm(){
	cudaFree(bnScale_);
	cudaFree(bnBias_);
	cudaFree(gradBnScale_);
	cudaFree(gradBnBias_);
	cudaFree(bnRunningMean_);
	cudaFree(bnRunningVar_);
	cudaFree(bnSavedMean_);
	cudaFree(bnSavedInvVariance_);
	cudaFree(m_bnScale_);
	cudaFree(v_bnScale_);
	cudaFree(m_bnBias_);
	cudaFree(v_bnBias_);
	checkCUDNN(cudnnDestroyTensorDescriptor(bnScaleBiasDesc_));
}
__half* BatchNorm::forward(__half* data){
	inData_ = data;
	checkCUDNN(
		cudnnBatchNormalizationForwardTraining(cudnnHandle_, bnMode_, &alpha, &beta0, outDesc_, data, outDesc_, outData_, bnScaleBiasDesc_, bnScale_, bnBias_, 1.0, bnRunningMean_, bnRunningVar_, epsilon_,
			bnSavedMean_, bnSavedInvVariance_));
	return outData_;
}
__half* BatchNorm::backward(__half* grad){
	checkCUDNN(cudnnBatchNormalizationBackward(
		cudnnHandle_,
		bnMode_,
		&alpha, &beta0, &alpha, &beta1,
		outDesc_, inData_,	 
		gradDesc_, grad,	    
		gradDesc_, grad,	   
		bnScaleBiasDesc_,	 
		bnScale_,			     
		gradBnScale_,		    
		gradBnBias_,		    
		epsilon_,
		bnSavedMean_, bnSavedInvVariance_));
	return grad;
}
void BatchNorm::updateParameters(float learningRate){
	AdamWFloat(bnScale_, m_bnScale_, v_bnScale_, 1.0f, gradBnScale_, outC_, t_, 0.000001F);
	AdamWFloat(bnBias_, m_bnBias_, v_bnBias_, 1.0f, gradBnBias_, outC_, t_, 0.000001F);
	++t_;
}