#pragma once
#include "common.h"
#include "Layer.h"
#include <cudnn.h>
#include <cublas_v2.h>
#include <vector>
class DiscardTokensLayer;
class NN{
public:
	NN(cudnnHandle_t cudnnHandle, cublasHandle_t cublasHandle, int w, int h, bool train);
	~NN();
	__half* Forward(__half* data);
	__half* Backward(__half* grad);
	void UpdateParams(float lr);
	void SaveModel(const std::string& filename);
	void SaveOptimizerState(const std::string& filename);
	void SetTrain(bool enable);
	cudnnHandle_t cudnn_;
	cublasHandle_t cublas_;
	std::vector<Layer*> layers_;
	int batchSize_;
	int seqLength_;
	int batchStateTotal_;
	int stateSize_;
	int inWidth_ = 0, inHeight_ = 0;
	size_t maxBufferSize_ = 0;
	int gradAccumLength_;
	int controlTokenCount_ = 0;
	int embedDim_ = 0;
	int controlInputDim_ = 0;
	int inputStride_ = 0;
	DiscardTokensLayer* discardLayer_ = nullptr;
};