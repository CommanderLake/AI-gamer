#include "training.h"
#include "ConvLayer.h"
#include "FCLayer.h"
#include "LeakyReLU.h"
#include "LayerNorm.h"
#include "Sigmoid.h"
#include <chrono>
#include <cuda.h>
#include <iomanip>
#include <iostream>
#include <random>
#include <string>
NeuralNetwork::NeuralNetwork(): inWidth_(0), inHeight_(0){
	cudnnCreate(&cudnn_);
	cublasCreate(&cublas_);
}
NeuralNetwork::~NeuralNetwork(){
	cudnnDestroy(cudnn_);
	cublasDestroy(cublas_);
	if(gradient_) cudaFree(gradient_);
	if(ctrlBatchFloat_) cuMemFreeHost(ctrlBatchFloat_);
	if(ctrlBatchHalf_) cuMemFreeHost(ctrlBatchHalf_);
}
void NeuralNetwork::Initialize(int w, int h){
	inWidth_ = w;
	inHeight_ = h;
	auto inputSize = w*h*3;
	layers_.push_back(new ConvLayer(cudnn_, cublas_, batchSize_, 3, 16, 8, 4, 2, &w, &h, &inputSize, 0, 0, "Conv0")); // Input: RGB image
	layers_.push_back(new LayerNorm(layers_.back()->outDesc_, batchSize_, "Conv0 LayerNorm"));
	layers_.push_back(new LeakyReLU(layers_.back()->outDesc_, "Conv0 LeakyReLU"));
	layers_.push_back(new ConvLayer(cudnn_, cublas_, batchSize_, 32, 64, 4, 2, 1, &w, &h, &inputSize, 0, 0, "Conv1"));
	layers_.push_back(new LayerNorm(layers_.back()->outDesc_, batchSize_, "Conv1 LayerNorm"));
	layers_.push_back(new LeakyReLU(layers_.back()->outDesc_, "Conv1 LeakyReLU"));
	layers_.push_back(new ConvLayer(cudnn_, cublas_, batchSize_, 64, 64, 3, 1, 1, &w, &h, &inputSize, 0, 0, "Conv2"));
	layers_.push_back(new LayerNorm(layers_.back()->outDesc_, batchSize_, "Conv2 LayerNorm"));
	layers_.push_back(new LeakyReLU(layers_.back()->outDesc_, "Conv2 LeakyReLU"));
	layers_.push_back(new FCLayer(cudnn_, cublas_, batchSize_, inputSize, 256, "FC0"));
	layers_.push_back(new LayerNorm(layers_.back()->outDesc_, batchSize_, "FC0 LayerNorm"));
	layers_.push_back(new LeakyReLU(layers_.back()->outDesc_, "FC0 LeakyReLU"));
	layers_.push_back(new FCLayer(cudnn_, cublas_, batchSize_, 256, numCtrls_, "FC1"));
	layers_.push_back(new Sigmoid(layers_.back()->outDesc_, numButs_, batchSize_, "FC1 Sigmoid"));
	checkCUDA(cudaMalloc(&gradient_, ctrlBatchSize_*sizeof(__half)));
	cudaMallocHost(reinterpret_cast<void**>(&ctrlBatchFloat_), ctrlBatchSize_*sizeof(float));
	cudaMallocHost(reinterpret_cast<void**>(&ctrlBatchHalf_), ctrlBatchSize_*sizeof(__half));
	cublasSetMathMode(cublas_, CUBLAS_TENSOR_OP_MATH);
}
__half* NeuralNetwork::Forward(__half* data, bool train){
	//printDataHalf(data, 10, "data");
	for(const auto layer : layers_){
		std::cout << layer->layerName_ << "\r\n";
		data = layer->Forward(data);
		PrintDataHalf(data, 16, "data");
	}
	return data;
}
void NeuralNetwork::Backward(const __half* d_predictions, const float* d_targets){
	//printDataFloat(d_targets, numCtrls, "Targets");
	Gradient(gradient_, d_predictions, d_targets, batchSize_, numCtrls_, 1.0f);
	auto outGrad = gradient_;
	for(int i = layers_.size(); --i >= 0; ){
		outGrad = layers_[i]->Backward(outGrad);
		PrintDataHalf(outGrad, 16, "outGrad");
	}
}
void NeuralNetwork::UpdateParams(){
	for(const auto layer : layers_){ layer->UpdateParameters(learningRate_); }
}
void NeuralNetwork::Train(InputRecord** data, size_t count){
	std::random_device rd;
	std::mt19937 gen(rd());
	const std::uniform_int_distribution<> dis(0, count - 1);
	const size_t inputSize = inWidth_*inHeight_*3;
	const size_t totalInputSize = inputSize*batchSize_;
	unsigned char* d_batchInputBytes = nullptr;
	__half* d_batchInputHalf = nullptr;
	checkCUDA(cudaMalloc(&d_batchInputBytes, totalInputSize*sizeof(unsigned char)));
	checkCUDA(cudaMalloc(&d_batchInputHalf, totalInputSize*sizeof(__half)));
	float* h_ctrlBatch = nullptr;
	cudaMallocHost(&h_ctrlBatch, ctrlBatchSize_*sizeof(float));
	float* d_ctrlBatch;
	checkCUDA(cudaMalloc(&d_ctrlBatch, ctrlBatchSize_*sizeof(float)));
	//int max = 0;
	for(size_t epoch = 0; epoch < 1000; ++epoch){
		// Number of epochs
		for(size_t batch = 0; batch < count / batchSize_; ++batch){
			for(size_t i = 0; i < batchSize_; ++i){
				const int index = dis(gen);
				const InputRecord* record = data[index];
				checkCUDA(cudaMemcpy(d_batchInputBytes + i*inputSize, record->state_data, inputSize*sizeof(unsigned char), cudaMemcpyHostToDevice));
				for(const auto& [makeCode, bit] : keyMap){
					if(record->keyStates & 1 << bit){
						h_ctrlBatch[i*numCtrls_ + bit] = 1.0f;
					} else h_ctrlBatch[i*numCtrls_ + bit] = 0.0f;
				}
				//max = std::max(max, std::max(std::abs(record->mouseDeltaX), std::abs(record->mouseDeltaY)));
				h_ctrlBatch[i*numCtrls_ + 14] = record->mouseDeltaX;
				h_ctrlBatch[i*numCtrls_ + 15] = record->mouseDeltaY;
			}
			checkCUDA(cudaMemcpy(d_ctrlBatch, h_ctrlBatch, numCtrls_*batchSize_*sizeof(float), cudaMemcpyHostToDevice));
			// Launch kernel to convert and normalize input
			ConvertAndNormalize(d_batchInputBytes, d_batchInputHalf, totalInputSize);
			// Perform forward pass
			ClearScreen();
			const auto output = Forward(d_batchInputHalf, true);
			//printDataFloat(d_ctrlBatch, numCtrls, "Target");
			//printDataHalf(output, numCtrls, "Predicted");
			// Compute loss
			const float loss = MseLoss(output, d_ctrlBatch, batchSize_*numCtrls_);
			std::cout << std::setprecision(10) << "Loss: " << loss << "\r\n\r\n";
			//std::cout << "Max: " << max << "\r\n\r\n";
			// Perform backward pass
			Backward(output, d_ctrlBatch);
			UpdateParams();
			//std::cout << "\r\n\r\n";
		}
	}
	cudaFreeHost(h_ctrlBatch);
	cudaFree(d_ctrlBatch);
	cudaFree(d_batchInputBytes);
	cudaFree(d_batchInputHalf);
}